PRODUCT WARRANTY MANAGEMENT SYSTEM

Folder layout (keep exactly like this):
  WarrantyManagementSystem.java   console app + data classes
  WarrantyServer.java             web server (REST API + serves ./web)
  web/index.html, style.css, app.js   browser frontend

A) Web version (recommended for the demo)
   javac WarrantyManagementSystem.java WarrantyServer.java
   java WarrantyServer
   Open http://localhost:8080

B) Console version only
   javac WarrantyManagementSystem.java
   java WarrantyManagementSystem

Run only one of A or B at a time (they share warranty_data.ser).
Run both commands from inside the WarrantyApp folder.
